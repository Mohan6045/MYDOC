package SearchP;

import org.openqa.selenium.WebDriver;

import PomPages.LoginPage;
import PomPages.RegisterPage;
import PomPages.Search;
import Utiles.ExplicitCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excel_utilities.getexcel;

public class SearchProduct extends getexcel {
	WebDriver dr;
	LoginPage d= new LoginPage(dr);
	 Search h= new  Search(dr);
	 
	ExplicitCode e= new ExplicitCode();
	getexcel g= new getexcel();
	@Given("^launch the browser$")
	public void launch_the_browser() throws Throwable {
		e.launchbrowser("chrome");
		 g.getExcel("Sheet1"); 
	}

	@When("^Search  with the invalid details(\\d+)$")
	public void search_with_the_invalid_details(int arg1) throws Throwable {
		int row = arg1;
		String fname = testdata[row][0];
		String lname = testdata[row][1];
		String email = testdata[row][2];
		String tele = testdata[row][3];
		int g = tele.length();
		String k = tele.substring(1, g - 1);
		String password = testdata[row][4];

		d.Login(email, password);
	  String r=testdata[row][5];
	  h.searchtheproduct(r);
	}

	@Then("^verify the Search product$")
	public void verify_the_Search_product() throws Throwable {
	    String q=h.errormessage();
	    if(q.contains("no product")) {
	    	System.out.println(q); 
	    }else {
	    	System.out.println("search success");
	    }
	}
}
