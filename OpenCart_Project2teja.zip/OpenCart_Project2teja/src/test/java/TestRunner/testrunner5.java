package TestRunner;


import org.testng.annotations.Test;



import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="src\\main\\resources\\Feature4",glue="Desktops")
public class testrunner5 extends AbstractTestNGCucumberTests{

}
