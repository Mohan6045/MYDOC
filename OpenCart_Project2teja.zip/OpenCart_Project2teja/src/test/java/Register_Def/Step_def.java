package Register_Def;

import org.openqa.selenium.WebDriver;

import PomPages.LoginPage;
import PomPages.RegisterPage;
import Utiles.ExplicitCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excel_utilities.getexcel;

public class Step_def extends getexcel{
	WebDriver dr;
	
	 LoginPage h= new  LoginPage(dr);
	 RegisterPage p= new RegisterPage(dr);
	ExplicitCode e= new ExplicitCode();
	getexcel g= new getexcel();
	@Given("^launch the browser$")
	public void launch_the_browser() throws Throwable {
		e.launchbrowser("chrome");
		 g.getExcel("Sheet1");
	}

	@When("^register with the valid details(\\d+)$")
	public void register_with_the_valid_details(int arg1) throws Throwable {
		int row=arg1;
		  String fname=testdata[row][0];
	      String lname=testdata[row][1];
	      String email=testdata[row][2];
	      String tele=testdata[row][3];
	      int g=tele.length();
	      String k=tele.substring(1, g-1);
	      String password=testdata[row][4];
	      p.Register(fname, lname, email, k, password);
	     
	}

	@Then("^verify the success register$")
	public void verify_the_success_register() throws Throwable {
	    String i=p.myaccount();
	    if(i.contains("My")) {
	    	System.out.println("sucessful register");
	    }else {
	    	System.out.println("unsucessful register");
	    }
	   // dr.close();
	}
}
