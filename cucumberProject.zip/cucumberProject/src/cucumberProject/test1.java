package cucumberProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	 WebDriver dr;
	 String test_result ;
@Given("^Browser is launched and login page displayed$")
public void browser_is_launched_and_login_page_displayed() throws Throwable {
 System.out.println("browser launched"); 
 System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
 dr= new ChromeDriver();
 dr.get("http://demowebshop.tricentis.com/login");
}

@When("^User enters login credentials and clicks on login$")
public void user_enters_login_credentials_and_clicks_on_login() throws Throwable {
	 System.out.println("login completed"); 
	 dr.findElement(By.xpath("//input[@class='email']")).sendKeys("tejasaisree0806@gmail.com");
	 dr.findElement(By.xpath("//input[@class='password']")).sendKeys("Tejaswarup12");
	 dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
}
@Then("^Successful login happens and profile nmae dispalyed correctly$")
public void successful_login_happens_and_profile_nmae_dispalyed_correctly() throws Throwable {
    
	 System.out.println("Successful login happens and profile nmae dispalyed correctly");
	String s= dr.findElement(By.xpath("//a[@class='account']")).getText();
	if(s.equals("tejasaisree0806@gmail.com")) {
		 test_result = "pass";
	}else
	{
		 test_result="fail"; 
	}
	System.out.println(test_result); 
}
}
