package Sauc_Utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Sauc_Browser {

	WebDriver dr;
	
	public WebDriver Launch_Browser(String browser,String url) {
		
		if(browser.contains("chrome")) {
			
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			dr=new ChromeDriver();
			
		}
		else if(browser.contains("firefox")) {
			
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr=new FirefoxDriver();
		}
		
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		return dr;
		
}

}

