$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "Automation Website",
  "description": "",
  "id": "automation-website",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "#1",
  "description": "Register with valid data",
  "id": "automation-website;#1",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "the user register using \"bltcts5562@gmail.com\" and \"Asvthoraipakkam9877\"",
  "keyword": "Then "
});
formatter.match({
  "location": "TestCucumber12.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 15628465000,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 1321946500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "bltcts5562@gmail.com",
      "offset": 25
    },
    {
      "val": "Asvthoraipakkam9877",
      "offset": 52
    }
  ],
  "location": "TestCucumber12.the_user_register_using_and(String,String)"
});
formatter.result({
  "duration": 4781824400,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "#2",
  "description": "Register with Invalid data",
  "id": "automation-website;#2",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "the user register using \"bltcts55@gmail.com\" and \"Asvthoraipakkam9877\"",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "Displays an error message that already registered",
  "keyword": "Then "
});
formatter.match({
  "location": "TestCucumber12.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 16136400300,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 1442341500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "bltcts55@gmail.com",
      "offset": 25
    },
    {
      "val": "Asvthoraipakkam9877",
      "offset": 50
    }
  ],
  "location": "TestCucumber12.the_user_register_using_and(String,String)"
});
formatter.result({
  "duration": 3554168800,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.Displays_an_error_message_that_already_registered()"
});
formatter.result({
  "duration": 158900,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 20,
  "name": "#3",
  "description": "login with Valid data",
  "id": "automation-website;#3",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 23,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "User enters valid login credentials  of set \u003cnumber\u003e \u0026 clicks on login",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "click on the login button user go to the next page",
  "keyword": "Then "
});
formatter.examples({
  "line": 28,
  "name": "",
  "description": "",
  "id": "automation-website;#3;",
  "rows": [
    {
      "cells": [
        "number"
      ],
      "line": 29,
      "id": "automation-website;#3;;1"
    },
    {
      "cells": [
        "0"
      ],
      "line": 30,
      "id": "automation-website;#3;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 30,
  "name": "#3",
  "description": "login with Valid data",
  "id": "automation-website;#3;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 23,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "User enters valid login credentials  of set 0 \u0026 clicks on login",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "click on the login button user go to the next page",
  "keyword": "Then "
});
formatter.match({
  "location": "TestCucumber12.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 15532182300,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 1667631600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "0",
      "offset": 44
    }
  ],
  "location": "TestCucumber12.user_enters_valid_login_credentials_of_set_clicks_on_login(int)"
});
formatter.result({
  "duration": 10208198200,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.click_on_the_login_button_user_go_to_the_next_page()"
});
formatter.result({
  "duration": 164900,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "#4",
  "description": "\t shop and add in the Automation website",
  "id": "automation-website;#4",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "user login using \"user45@gmail.com\" and \"mohankumar@6045\"",
  "keyword": "Then "
});
formatter.step({
  "line": 38,
  "name": "user click on the shop button and click on the add to cart button",
  "keyword": "Then "
});
formatter.match({
  "location": "TestCucumber12.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 20894777500,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 1811472500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "user45@gmail.com",
      "offset": 18
    },
    {
      "val": "mohankumar@6045",
      "offset": 41
    }
  ],
  "location": "TestCucumber12.user_login_using_and(String,String)"
});
formatter.result({
  "duration": 5891702100,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.user_click_on_the_shop_button_and_click_on_the_add_to_cart_button()"
});
formatter.result({
  "duration": 9110995800,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "#5",
  "description": "Open Demo Suite for registration",
  "id": "automation-website;#5",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "user login using \"user45@gmail.com\" and \"mohankumar@6045\"",
  "keyword": "Then "
});
formatter.step({
  "line": 47,
  "name": "user click on the Demo site and enters the details",
  "keyword": "Then "
});
formatter.match({
  "location": "TestCucumber12.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 22819281200,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 1353571700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "user45@gmail.com",
      "offset": 18
    },
    {
      "val": "mohankumar@6045",
      "offset": 41
    }
  ],
  "location": "TestCucumber12.user_login_using_and(String,String)"
});
formatter.result({
  "duration": 6466760300,
  "status": "passed"
});
formatter.match({
  "location": "TestCucumber12.user_click_on_the_Demo_site_and_enters_the_details()"
});
formatter.result({
  "duration": 14201473300,
  "status": "passed"
});
});