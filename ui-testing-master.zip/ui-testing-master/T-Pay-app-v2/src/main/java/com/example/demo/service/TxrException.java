package com.example.demo.service;

@SuppressWarnings("serial")
public class TxrException extends RuntimeException {

	public TxrException(String message) {
		super(message);
	}
}
