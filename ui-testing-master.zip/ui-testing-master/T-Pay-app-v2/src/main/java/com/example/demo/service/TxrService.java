package com.example.demo.service;

public interface TxrService {

	public boolean txr(double amount, String fromAccNum, String toAccNum);

}
