package com.example;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SimpleTest {
	
	@Test
	public void beTrue() {
		AssertJUnit.assertTrue(true);
	}

}
